package fr.arinonia.openjupdate.config;

public class DataInitializer {
}
